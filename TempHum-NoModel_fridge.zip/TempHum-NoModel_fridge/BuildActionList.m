function [ actions ] = BuildActionList
%BuildActionList
% 1 = bulb1_on, 
% 2 = bulb1_off,
% 3 = bulb2_on,
% 4 = bulb2_off,
% 5 = do nothing


%action numbers
actions = [1 2 3 4 5];